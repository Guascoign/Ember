```eval_rst
.. include:: /header.rst 
:github_url: |github_link_base|/object-types/index.md
```
# Widgets

```eval_rst

.. toctree::
   :maxdepth: 1
   
   obj
   core/index
   extra/index
```


