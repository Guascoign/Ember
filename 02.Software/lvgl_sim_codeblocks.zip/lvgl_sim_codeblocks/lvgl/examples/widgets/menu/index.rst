
Simple Menu 
""""""""""""""""

.. lv_example:: widgets/menu/lv_example_menu_1
  :language: c
  
Simple Menu with root btn
""""""""""""""""""""""""""""

.. lv_example:: widgets/menu/lv_example_menu_2
  :language: c
  
Simple Menu with custom header
""""""""""""""""""""""""""""

.. lv_example:: widgets/menu/lv_example_menu_3
  :language: c

Simple Menu with floating btn to add new menu page
""""""""""""""""""""""""""""

.. lv_example:: widgets/menu/lv_example_menu_4
  :language: c
  
Complex Menu
""""""""""""""""""""""""""""

.. lv_example:: widgets/menu/lv_example_menu_5
  :language: c

