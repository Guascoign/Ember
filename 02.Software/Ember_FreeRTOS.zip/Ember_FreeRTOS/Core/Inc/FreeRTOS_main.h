
#ifndef __FREERTOS_DEMO_H
#define __FREERTOS_DEMO_H

void freertos_main(void);

#endif
