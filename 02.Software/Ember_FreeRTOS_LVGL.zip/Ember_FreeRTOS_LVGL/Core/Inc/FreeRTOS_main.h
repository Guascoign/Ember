
#ifndef __FREERTOS_MAIN_H
#define __FREERTOS_MAIN_H


void freertos_start(void);



#endif
