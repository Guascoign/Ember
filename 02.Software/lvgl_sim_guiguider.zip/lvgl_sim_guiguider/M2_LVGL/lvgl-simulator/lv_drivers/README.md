# Display and Touch pad drivers

Display controller and touchpad driver to can be directly used with [LittlevGL](https://littlevgl.com).

To learn more about using drivers in LittlevGL visit the [Porting guide](https://docs.lvgl.io/latest/en/html/porting/index.html).

If you used a new display or touch pad driver with LittlevGL please share it with other people!
