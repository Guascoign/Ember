/********************���ݳ�**************************
*****************1.3��  10PIN  spi for stm8*************
***** BY:GU 
ST7735S
��ģ���Դ��ֿ��ͺţ����ݳ������ֿ�V1.0  �ֿ�洢Ϊˮƽɨ�跽ʽ���ϵ��£�����һ�ֽڲ���

ͨ��csѡ������CS2ѡ���ֿ�
��ģ���Դ������������裬ʹ��BL ���ŵ����������ȣ��Ƽ�ʹ��pwm�źſ������ȣ�Ҳ��ֱ�Ӹߵ�ƽ


********************************************************/
#include "IOSTM8S003F3.h"

#define set_0   0x01
#define set_1   0x02
#define set_2   0x04
#define set_3   0x08    
#define set_4   0x10
#define set_5   0x20
#define set_6   0x40
#define set_7   0x80

#define clr_0   0xFE
#define clr_1   0xFD
#define clr_2   0xFB
#define clr_3   0xF7    
#define clr_4   0xEF
#define clr_5   0xDF
#define clr_6   0xBF
#define clr_7   0x7F

/**********SPI���ŷ��䣬����TFT��������ʵ������޸�*********/
#define SPI_SCK_0  PC_ODR&=clr_3        //PC3       
#define SPI_SCK_1  PC_ODR|=set_3       
#define SPI_SDA_0  PC_ODR&=clr_4        //PC4        
#define SPI_SDA_1  PC_ODR|=set_4
#define SPI_FSO   ( PC_IDR & set_5 ) 
#define SPI_RST_0  PC_ODR&=clr_6        //PC6       
#define SPI_RST_1  PC_ODR|=set_6       
#define SPI_DC_0  PC_ODR&=clr_7        //PC7        
#define SPI_DC_1  PC_ODR|=set_7
#define SPI_CS_0  PD_ODR&=clr_4        //PD4      
#define SPI_CS_1  PD_ODR|=set_4       
#define SPI_CS2_0  PD_ODR&=clr_5        //PD5      
#define SPI_CS2_1  PD_ODR|=set_5
#define BL_0  PD_ODR&=clr_6        //PD6      
#define BL_1  PD_ODR|=set_6     

//������ʾ�����С��ƫ��
#define TFT_COLUMN_NUMBER 240
#define TFT_LINE_NUMBER 240
#define TFT_COLUMN_OFFSET 0
#define TFT_LINE_OFFSET 0
#define PIC_NUM 28800			//ͼƬ���ݴ�С

//���峣����ɫ
#define 	BLACK  0  //��ɫ
#define 	RED  1  //��ɫ
#define 	GREEN 2  //��ɫ
#define 	BLUE  3  //��ɫ
#define 	WHITE  4  //��ɫ
#define PIC_LEN 120
#define PIC_HIG 120


//ָ���
#define W25X_WriteEnable 0x06
#define W25X_WriteDisable 0x04
#define W25X_ReadStatusReg 0x05
#define W25X_WriteStatusReg 0x01
#define W25X_ReadData 0x03
#define W25X_FastReadData 0x0B
#define W25X_FastReadDual 0x3B
#define W25X_PageProgram 0x02
#define W25X_BlockErase 0xD8
#define W25X_SectorErase 0x20
#define W25X_ChipErase 0xC7
#define W25X_PowerDown 0xB9
#define W25X_ReleasePowerDown 0xAB
#define W25X_DeviceID 0xAB
#define W25X_ManufactDeviceID 0x90
#define W25X_JedecDeviceID 0x9F

//�ֿ����ַ
#define CHAR6_12_ADD     0X1000L 
#define CHAR7_14_ADD     0X1600L
#define CHAR8_16_ADD     0X1D00L 
#define CHAR9_18_ADD     0X2500L
#define CHAR10_20_ADD     0X3700L
#define CHAR11_22_ADD     0X4B00L 
#define CHAR12_24_ADD     0X6100L
#define CHAR13_26_ADD     0X7900L

#define CHINA12_12_ADD     0X9300L 
#define CHINA14_14_ADD     0X39300L 
#define CHINA16_16_ADD     0X71300L 
#define CHINA18_18_ADD     0XB1300L 
#define CHINA20_20_ADD     0X11D300L 
#define CHINA22_22_ADD     0X195300L
#define CHINA24_24_ADD     0X219300L
#define CHINA26_26_ADD     0X2A9300L 
#define END_ADD             0X379300L


#define TRUE             1
#define FALSE           0

typedef enum        // ��ͬ����ѡ��
{
     SONG_STYLE12,SONG_STYLE14,SONG_STYLE16,SONG_STYLE18,SONG_STYLE20,SONG_STYLE22,SONG_STYLE24,SONG_STYLE26
}type_of_font;
type_of_font TYPE_OF_STYLE;

struct                   //��ʾ�ַ��������ݽṹ��
{                
    unsigned char  CHAR_WIDE;           //Ӣ���������       
    unsigned char  CHAR_HIGH;           //Ӣ������߶�
    unsigned char  WORD_WIDE;           //���ֿ���
    unsigned char  WORD_HIGH;           //���ָ߶�
    unsigned  int CHAR_DATA_SIZE;     //Ӣ��һ���ַ������ݴ�С  �ֽ�
    unsigned  int WORD_DATA_SIZE;     //����һ���ַ������ݴ�С  �ֽ�
    unsigned  int  BACK_COLOR;              //�ַ���ɫ
    unsigned  int  FONT_COLOR;              //�ַ���ɫ
    unsigned long   BASE_WORD_ADD;           //�����ֿ����ַ
    unsigned long   BASE_CHAR_ADD;           //Ӣ���ֿ����ַ
} DIS_CHAR_MODE ;
const unsigned char TAB_COLOR[][2] = 
{
    0X00,0X00,      //��ɫ
    0XF8,0X00,	  //��ɫ
    0X07,0XE0,	  //��ɫ
    0X00,0X1F,	  //��ɫ
    0XFF,0XFF,	  //��ɫ
};
unsigned char FONT_BUFFER[104];         //�ֿ⻺�棬֧�����26*26���֣���4*26�ֽ�


const unsigned char  picture_tab[]={
/*------------------------------------------------------------------------------
;  ����ʽ����λ��ǰ������
;  �����ߣ����أ�: 128��64
------------------------------------------------------------------------------*/
    0xFF,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0xFF,
0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x20,0x44,0x08,0x00,0x18,0x48,0x28,0xC8,0x08,0x28,0x48,0x18,0x00,
0x40,0x40,0xFC,0x40,0x40,0xFC,0x00,0x00,0xF8,0x00,0x00,0xFC,0x00,0x40,0x40,0xA0,
0x90,0x88,0x84,0x88,0x90,0x20,0x40,0x40,0x00,0x00,0x40,0x44,0xD8,0x20,0xF0,0xAC,
0xA8,0xE8,0xB8,0xA8,0xE0,0x00,0x00,0x00,0xC0,0x7C,0x54,0x54,0x54,0x54,0x54,0x54,
0x7C,0x40,0x40,0x00,0x00,0xF0,0x90,0x90,0x90,0xFC,0x90,0x90,0x90,0xF0,0x00,0x00,
0x00,0x80,0x88,0x88,0x88,0x88,0x88,0xE8,0xA8,0x98,0x8C,0x88,0x80,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x04,0x3E,0x01,0x10,0x11,0x09,0x05,0x3F,0x05,0x09,0x11,0x11,0x00,
0x08,0x18,0x0F,0x24,0x14,0x0F,0x00,0x00,0x0F,0x00,0x00,0x3F,0x00,0x20,0x22,0x2A,
0x32,0x22,0x3F,0x22,0x32,0x2A,0x22,0x20,0x00,0x00,0x20,0x10,0x0F,0x10,0x28,0x24,
0x23,0x20,0x2F,0x28,0x2A,0x2C,0x00,0x30,0x0F,0x04,0x3D,0x25,0x15,0x15,0x0D,0x15,
0x2D,0x24,0x24,0x00,0x00,0x07,0x04,0x04,0x04,0x1F,0x24,0x24,0x24,0x27,0x20,0x38,
0x00,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
0xFF,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0xFF,
0xFF,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x81,0x41,0x21,0x21,0x61,0x01,0x01,0x21,0xE1,0xE1,0x01,0xE1,0xE1,
0x21,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x21,0xE1,0x21,0x21,0x21,0x61,0x01,0x01,
0x21,0x21,0xE1,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0xC1,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x21,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,
0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0xFF,
0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x0F,0x10,0x20,0x24,0x1C,0x04,0x00,0x20,0x3F,0x01,0x3E,0x01,0x3F,
0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x22,0x22,0x27,0x30,0x00,0x00,
0x20,0x20,0x3F,0x20,0x20,0x00,0x00,0x1E,0x25,0x25,0x25,0x16,0x00,0x00,0x1E,0x21,
0x21,0x21,0x13,0x00,0x01,0x01,0x1F,0x21,0x21,0x00,0x00,0x00,0x21,0x3F,0x22,0x21,
0x01,0x00,0x00,0x1E,0x21,0x21,0x21,0x1E,0x00,0x21,0x3F,0x22,0x01,0x01,0x3E,0x20,
0x00,0x21,0x21,0x3F,0x20,0x20,0x00,0x00,0x1E,0x21,0x21,0x21,0x13,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0xF0,0x08,0x04,0x04,0x04,0x0C,0x00,0xF0,0x08,0x04,0x04,0x08,0xF0,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0xFC,0x04,0x00,
0x00,0x00,0x00,0x00,0x0C,0x04,0xFC,0x04,0x0C,0x00,0x04,0xFC,0x04,0x04,0x08,0xF0,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
0xFF,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x81,0x82,0x84,0x84,0x84,0x82,0x80,0x81,0x82,0x84,0x84,0x82,0x81,
0x80,0x80,0x86,0x86,0x80,0x80,0x80,0x80,0x80,0x85,0x83,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x84,0x87,0x84,0x84,
0x84,0x86,0x80,0x80,0x80,0x84,0x87,0x84,0x80,0x80,0x84,0x87,0x84,0x84,0x82,0x81,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0xFF

};

/*******ʱ�ӳ�ʼ��******************/
void CLK_init(void)
{
  
  CLK_CKDIVR|= 0x00;       /*����ʱ��Ϊ�ڲ�16M����ʱ��*/ 
}
void delay_us(unsigned long _us_time)
{       
  unsigned char x=0;
  for(;_us_time>0;_us_time--)
  {
    x++;
  }
}
void delay_ms(unsigned long _ms_time)
  {
    unsigned int i,j;
    for(i=0;i<_ms_time;i++)
    {
    for(j=0;j<100;j++)
      {;}
    }
  }
/*************SPI���ú���*******************
SCL����ʱ�͵�ƽ����һ�������ز���
ģ��SPI
******************************************/

/**************************SPIģ�鷢�ͺ���************************************************

 *************************************************************************/
void SPI_SendByte(unsigned  char byte)        //��SPI�ӿ�дһ��8λ����
{ 
  unsigned char counter;   
  for(counter=0;counter<8;counter++)
  { 
    SPI_SCK_0;    
    if((byte&0x80)==0)
    {
      SPI_SDA_0;
    }
    else SPI_SDA_1;
    byte=byte<<1; 
    SPI_SCK_1;      
  }
  
  SPI_SCK_0;
}

void TFT_SEND_CMD(unsigned char o_command)
  {
    SPI_DC_0;
    SPI_CS_0;
    SPI_SendByte(o_command);
    SPI_CS_1;
	 
    //SPI_DC_1;
  }
void TFT_SEND_DATA(unsigned char o_data)
  { 
    SPI_DC_1;
    SPI_CS_0;
    SPI_SendByte(o_data);
    SPI_CS_1;
	  
   }
 void TFT_SET_ADD(unsigned  int x_start,unsigned  int y_start,unsigned  int x_end,unsigned  int y_end)
{
	unsigned  int x = x_start + TFT_COLUMN_OFFSET,y=x_end+ TFT_COLUMN_OFFSET;
    TFT_SEND_CMD(0x2a);     //Column address set
    TFT_SEND_DATA(x>>8);    //start column
    TFT_SEND_DATA(x); 
    TFT_SEND_DATA(y>>8);    //end column
    TFT_SEND_DATA(y);
	x = y_start + TFT_LINE_OFFSET;
	y=y_end+ TFT_LINE_OFFSET;
    TFT_SEND_CMD(0x2b);     //Row address set
    TFT_SEND_DATA(x>>8);    //start row
    TFT_SEND_DATA(x); 
    TFT_SEND_DATA(y>>8);    //end row
    TFT_SEND_DATA(y);
    TFT_SEND_CMD(0x2C);     //Memory write
    
}
void TFT_clear(void)
  {
    unsigned int ROW,column;
    TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);
    for(ROW=0;ROW<TFT_LINE_NUMBER;ROW++)             //ROW loop
      { 
    
          for(column=0;column<TFT_COLUMN_NUMBER;column++)  //column loop
            {
              
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xFF);
            }
      }
  }

void TFT_full(unsigned int color)
  {
    unsigned int ROW,column;
    TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);
    for(ROW=0;ROW<TFT_LINE_NUMBER;ROW++)             //ROW loop
    { 
    
        for(column=0;column<TFT_COLUMN_NUMBER ;column++) //column loop
        {

			TFT_SEND_DATA(TAB_COLOR[color][0]);
			TFT_SEND_DATA(TAB_COLOR[color][1]);
        }
    }
  }
  
  
  
//��ȡSPI FLASH
//��ָ����ַ��ʼ��ȡָ�����ȵ�����
//pBuffer:���ݴ洢��
//ReadAddr:��ʼ��ȡ�ĵ�ַ(24bit)
//NumByteToRead:Ҫ��ȡ���ֽ���(���65535)
void W25QXX_Read(unsigned char *pBuffer, unsigned long ReadAddr, unsigned  int NumByteToRead)
{
	unsigned  int i;
    unsigned char counter,redata=0;
	SPI_CS2_0;					   //ʹ������
	SPI_SendByte(W25X_ReadData);//���Ͷ�ȡ����		   
	SPI_SendByte((unsigned char)(ReadAddr >> 16));    //����24bit��ַ
    SPI_SendByte((unsigned char)(ReadAddr >> 8));    //����24bit��ַ
    SPI_SendByte((unsigned char)(ReadAddr));    //����24bit��ַ
	for (i = 0; i < NumByteToRead; i++)         //ѭ������
	{           
      for(counter=0;counter<8;counter++)
      { 
            SPI_SCK_0;	  
            SPI_SDA_1;
            redata <<=1;
            if(SPI_FSO)
            {
               redata |=0x01; 
            }	
            SPI_SCK_1;			
      }
      
        SPI_SCK_0;
        pBuffer[i] = redata;
	}
	SPI_CS2_1;
}
unsigned char CHECK_FALSH(void)
{
    unsigned int x=0;
    const unsigned char string[] = "JYC-4MbByte-FONT-FLASH";
    W25QXX_Read(FONT_BUFFER, 0X000000, 22);
    for(x=0;x<22;x++)
    {
       if(FONT_BUFFER[x] != string[x]) 
       {
           return(FALSE);
       } 
    }
    return(TRUE);
}
void SET_FONT_STYLE (unsigned char font_color,unsigned char back_color,type_of_font TYPE_CHAR)  
{
    DIS_CHAR_MODE.BACK_COLOR = back_color;
    DIS_CHAR_MODE.FONT_COLOR = font_color;
    switch (TYPE_CHAR)
    {
        case SONG_STYLE12: 
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR6_12_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA12_12_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 1*12;
                DIS_CHAR_MODE.CHAR_HIGH = 12;
                DIS_CHAR_MODE.CHAR_WIDE = 6;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 2*12;
                DIS_CHAR_MODE.WORD_HIGH = 12;
                DIS_CHAR_MODE.WORD_WIDE = 12;
            break;
        
        case SONG_STYLE14:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR7_14_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA14_14_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 1*14;
                DIS_CHAR_MODE.CHAR_HIGH = 14;
                DIS_CHAR_MODE.CHAR_WIDE = 7;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 2*14;
                DIS_CHAR_MODE.WORD_HIGH = 14;
                DIS_CHAR_MODE.WORD_WIDE = 14;
            break;
        case SONG_STYLE16:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR8_16_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA16_16_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 1*16;
                DIS_CHAR_MODE.CHAR_HIGH = 16;
                DIS_CHAR_MODE.CHAR_WIDE = 8;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 2*16;
                DIS_CHAR_MODE.WORD_HIGH = 16;
                DIS_CHAR_MODE.WORD_WIDE = 16;
            break;
        case SONG_STYLE18:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR9_18_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA18_18_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 2*18;
                DIS_CHAR_MODE.CHAR_HIGH = 18;
                DIS_CHAR_MODE.CHAR_WIDE = 9;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 3*18;
                DIS_CHAR_MODE.WORD_HIGH = 18;
                DIS_CHAR_MODE.WORD_WIDE = 18;
            break;
        case SONG_STYLE20:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR10_20_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA20_20_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 2*20;
                DIS_CHAR_MODE.CHAR_HIGH = 20;
                DIS_CHAR_MODE.CHAR_WIDE = 10;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 3*20;
                DIS_CHAR_MODE.WORD_HIGH = 20;
                DIS_CHAR_MODE.WORD_WIDE = 20;
            break;
        case SONG_STYLE22:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR11_22_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA22_22_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 2*22;
                DIS_CHAR_MODE.CHAR_HIGH = 22;
                DIS_CHAR_MODE.CHAR_WIDE = 11;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 3*22;
                DIS_CHAR_MODE.WORD_HIGH = 22;
                DIS_CHAR_MODE.WORD_WIDE = 22;
            break;
        case SONG_STYLE24:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR12_24_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA24_24_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 2*24;
                DIS_CHAR_MODE.CHAR_HIGH = 24;
                DIS_CHAR_MODE.CHAR_WIDE = 12;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 3*24;
                DIS_CHAR_MODE.WORD_HIGH = 24;
                DIS_CHAR_MODE.WORD_WIDE = 24;
            break;
        case SONG_STYLE26:
                DIS_CHAR_MODE.BASE_CHAR_ADD = CHAR13_26_ADD;
                DIS_CHAR_MODE.BASE_WORD_ADD = CHINA26_26_ADD;
                DIS_CHAR_MODE.CHAR_DATA_SIZE = 2*26;
                DIS_CHAR_MODE.CHAR_HIGH = 26;
                DIS_CHAR_MODE.CHAR_WIDE = 13;
                DIS_CHAR_MODE.WORD_DATA_SIZE = 4*26;
                DIS_CHAR_MODE.WORD_HIGH = 26;
                DIS_CHAR_MODE.WORD_WIDE = 26;
            break;
    }
    
}
void DIS_CHINESE(unsigned  int x_start,unsigned  int y_start,char *string)      //��ʾ�ַ�����֧����Ӣ����/GB2312����
{
    unsigned char times=0,CACHE=0;
    unsigned long Address;
      unsigned int x=0,z=0,m,n,f;
    char  WORD_CODE_MSB,WORD_CODE_LSB;
    unsigned int ADD_X_START = x_start, \
                 ADD_Y_START = y_start,  \
                 ADD_X_END = x_start + DIS_CHAR_MODE.WORD_WIDE-1,  \
                 ADD_Y_END = y_start + DIS_CHAR_MODE.WORD_HIGH;
    
    

/*******************************************/
   while(*string!='\0')
    { 
        WORD_CODE_MSB = *string++;
        WORD_CODE_LSB = *string++;
        
        if(((unsigned char)WORD_CODE_MSB>=0xA1) &&  ((unsigned char)WORD_CODE_LSB >=0xA1))            //GB2312���뷶Χ,���к�1410  Ϊ���� ����Ϊ����������   
        {
            Address = (WORD_CODE_MSB - 0xA1) * 94 ;
            Address = (Address + (WORD_CODE_LSB - 0xA1));
            Address =Address *(DIS_CHAR_MODE.WORD_DATA_SIZE);
             Address =Address + DIS_CHAR_MODE.BASE_WORD_ADD ;  
            W25QXX_Read(FONT_BUFFER, Address, (DIS_CHAR_MODE.WORD_DATA_SIZE));            
            ADD_X_END = ADD_X_START + DIS_CHAR_MODE.WORD_WIDE-1;
                  
/*******************************��ַ�趨************************************///������ʾ

            if((ADD_X_END>(TFT_COLUMN_NUMBER-1)) )          //����x��ַ��Χ,ת����һ��
            {                                           
                 ADD_Y_START = ADD_Y_END;
                 ADD_X_START = 0;
                 ADD_X_END = DIS_CHAR_MODE.WORD_WIDE-1;            
                 ADD_Y_END = ADD_Y_START + DIS_CHAR_MODE.WORD_HIGH;
                 if (ADD_Y_END > TFT_LINE_NUMBER )       //����Y��Χ
                 {
                    ADD_Y_START = 0;                          //�ƶ�����һ��
                    ADD_Y_END =  DIS_CHAR_MODE.WORD_HIGH; 
                        
                 }
            }
            TFT_SET_ADD(ADD_X_START,ADD_Y_START,ADD_X_END,ADD_Y_END);
            TFT_SEND_CMD(0x2C);     //д����   
/************************************************����ɫ��ʾ*************************************************************/              
            z = 0;
            for (x=0;x<DIS_CHAR_MODE.WORD_HIGH ;x++)      //������ʾ
            {   
                    m = DIS_CHAR_MODE.WORD_WIDE / 8;
                    f = DIS_CHAR_MODE.WORD_WIDE % 8;
                    for(n=0;n<m;n++)            //  ȡ�����ֽ�
                    {
                        CACHE = FONT_BUFFER[z++];
                        for(times=0;times<8;times++)
                        {
                            if ((CACHE&0x80)==0)                //������,����ɫ
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][1]); 
                                                           
                            }
                            else
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][1]); 
                                
                            }
                            CACHE = CACHE<<1;
                        }
                    }
                    if (f!=0)
                    {
                        CACHE = FONT_BUFFER[z++];
                        for(times=0;times<f;times++)        //  ȡ�������ֽ�
                        {
                            if ((CACHE&0x80)==0)                //������,����ɫ
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][1]); 
                                                              
                            }
                            else
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][1]); 
                                    
                            }
                            CACHE = CACHE<<1;
                        }
                    }
            }                
            ADD_X_START = ADD_X_END;  
        }
        else    //Ӣ�ķ�Χ
        {           

            Address = (WORD_CODE_MSB ) * DIS_CHAR_MODE.CHAR_DATA_SIZE + DIS_CHAR_MODE.BASE_CHAR_ADD; 
            string--;
            ADD_X_END = ADD_X_START + DIS_CHAR_MODE.CHAR_WIDE-1;             
            W25QXX_Read(FONT_BUFFER, Address, (DIS_CHAR_MODE.CHAR_DATA_SIZE)); 

 /*******************************��ַ�趨************************************/
                
             //�жϵ�ַ�Ƿ�Ϸ�
                if((ADD_X_END>(TFT_COLUMN_NUMBER-1)) )          //����x��ַ��Χ,ת����һ��
                {                                           
                    ADD_Y_START = ADD_Y_START+(ADD_X_END/(TFT_COLUMN_NUMBER-1)) * DIS_CHAR_MODE.CHAR_HIGH;
                    ADD_X_START = 0;//((ADD_X_END % TFT_COLUMN_NUMBER) / DIS_CHAR_MODE.WORD_WIDE ) *DIS_CHAR_MODE.WORD_WIDE + DIS_CHAR_MODE.WORD_WIDE;
                    ADD_X_END = DIS_CHAR_MODE.CHAR_WIDE-1;            
                    ADD_Y_END = ADD_Y_START + DIS_CHAR_MODE.CHAR_HIGH;
                    if (ADD_Y_END > (TFT_LINE_NUMBER-1) )       //����Y��Χ
                    {
                        ADD_Y_START = 0;                          //�ƶ�����һ��
                        ADD_Y_END =  DIS_CHAR_MODE.CHAR_HIGH; 
                        
                    }
                    
                }
           
            TFT_SET_ADD(ADD_X_START,ADD_Y_START,ADD_X_END,ADD_Y_END);
/*************************************************************************************************************/      
            z = 0;
            for (x=0;x<DIS_CHAR_MODE.CHAR_HIGH ;x++)      //������ʾ
            {   
                    m = DIS_CHAR_MODE.CHAR_WIDE / 8;
                    f = DIS_CHAR_MODE.CHAR_WIDE % 8;
                    for(n=0;n<m;n++)            //  ȡ�����ֽ�
                    {
                        CACHE = FONT_BUFFER[z++];
                        for(times=0;times<8;times++)
                        {
                            if ((CACHE&0x80)==0)                //������,����ɫ
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][1]); 
                                                           
                            }
                            else
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][1]); 
                                
                            }
                            CACHE = CACHE<<1;
                        }
                    }
                    if (f!=0)
                    {
                        CACHE = FONT_BUFFER[z++];
                        for(times=0;times<f;times++)        //  ȡ�������ֽ�
                        {
                            if ((CACHE&0x80)==0)                //������,����ɫ
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.BACK_COLOR][1]); 
                                                              
                            }
                            else
                            {
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][0]);
                                TFT_SEND_DATA(TAB_COLOR[DIS_CHAR_MODE.FONT_COLOR][1]); 
                                    
                            }
                            CACHE = CACHE<<1;
                        }
                    }
              }         
            ADD_X_START = ADD_X_END;        
        }
    }            
}
void TFT_init(void)				////ST7789V2
  {
	SPI_SCK_1;			//�ر�ע�⣡��
	SPI_RST_0;
	delay_ms(1000);
	SPI_RST_1;
	delay_ms(1000);
    TFT_SEND_CMD(0x11); 			//Sleep Out
	delay_ms(120);               //DELAY120ms 
	 	  //-----------------------ST7789V Frame rate setting-----------------//
//************************************************
                TFT_SEND_CMD(0x3A);        //65k mode
                TFT_SEND_DATA(0x05);
                TFT_SEND_CMD(0xC5); 		//VCOM
                TFT_SEND_DATA(0x1A);
                TFT_SEND_CMD(0x36);                 // ��Ļ��ʾ��������
                TFT_SEND_DATA(0x00);
                //-------------ST7789V Frame rate setting-----------//
                TFT_SEND_CMD(0xb2);		//Porch Setting
                TFT_SEND_DATA(0x05);
                TFT_SEND_DATA(0x05);
                TFT_SEND_DATA(0x00);
                TFT_SEND_DATA(0x33);
                TFT_SEND_DATA(0x33);

                TFT_SEND_CMD(0xb7);			//Gate Control
                TFT_SEND_DATA(0x05);			//12.2v   -10.43v
                //--------------ST7789V Power setting---------------//
                TFT_SEND_CMD(0xBB);//VCOM
                TFT_SEND_DATA(0x3F);

                TFT_SEND_CMD(0xC0); //Power control
                TFT_SEND_DATA(0x2c);

                TFT_SEND_CMD(0xC2);		//VDV and VRH Command Enable
                TFT_SEND_DATA(0x01);

                TFT_SEND_CMD(0xC3);			//VRH Set
                TFT_SEND_DATA(0x0F);		//4.3+( vcom+vcom offset+vdv)

                TFT_SEND_CMD(0xC4);			//VDV Set
                TFT_SEND_DATA(0x20);				//0v

                TFT_SEND_CMD(0xC6);				//Frame Rate Control in Normal Mode
                TFT_SEND_DATA(0X01);			//111Hz

                TFT_SEND_CMD(0xd0);				//Power Control 1
                TFT_SEND_DATA(0xa4);
                TFT_SEND_DATA(0xa1);

                TFT_SEND_CMD(0xE8);				//Power Control 1
                TFT_SEND_DATA(0x03);

                TFT_SEND_CMD(0xE9);				//Equalize time control
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x08);
                //---------------ST7789V gamma setting-------------//
                TFT_SEND_CMD(0xE0); //Set Gamma
                TFT_SEND_DATA(0xD0);
                TFT_SEND_DATA(0x05);
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x08);
                TFT_SEND_DATA(0x14);
                TFT_SEND_DATA(0x28);
                TFT_SEND_DATA(0x33);
                TFT_SEND_DATA(0x3F);
                TFT_SEND_DATA(0x07);
                TFT_SEND_DATA(0x13);
                TFT_SEND_DATA(0x14);
                TFT_SEND_DATA(0x28);
                TFT_SEND_DATA(0x30);
                 
                TFT_SEND_CMD(0XE1); //Set Gamma
                TFT_SEND_DATA(0xD0);
                TFT_SEND_DATA(0x05);
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x09);
                TFT_SEND_DATA(0x08);
                TFT_SEND_DATA(0x03);
                TFT_SEND_DATA(0x24);
                TFT_SEND_DATA(0x32);
                TFT_SEND_DATA(0x32);
                TFT_SEND_DATA(0x3B);
                TFT_SEND_DATA(0x14);
                TFT_SEND_DATA(0x13);
                TFT_SEND_DATA(0x28);
                TFT_SEND_DATA(0x2F);

                TFT_SEND_CMD(0x21); 		//����
               
                TFT_SEND_CMD(0x29);         //������ʾ 

  }
void Picture_display(const unsigned char *ptr_pic)
  {
    unsigned int ROW,column;
	TFT_SEND_CMD(0x2a);     //Column address set
  TFT_SEND_DATA(0x00);    //start column
  TFT_SEND_DATA(0x00+TFT_COLUMN_OFFSET); 
  TFT_SEND_DATA(0x00);    //end column
  TFT_SEND_DATA(PIC_LEN-1+ TFT_COLUMN_OFFSET);

  TFT_SEND_CMD(0x2b);     //Row address set
  TFT_SEND_DATA(0x00);    //start row
  TFT_SEND_DATA(0x00+TFT_LINE_OFFSET); 
  TFT_SEND_DATA(0x00);    //end row
  TFT_SEND_DATA(PIC_HIG-1+ TFT_LINE_OFFSET);
    TFT_SEND_CMD(0x2C);     //Memory write
    for(ROW=0;ROW<PIC_HIG;ROW++)        //ROW loop
      {   
		
	for(column=0;column<PIC_LEN;column++)	//column loop
          {
            TFT_SEND_DATA(*ptr_pic++);
			TFT_SEND_DATA(*ptr_pic++);
          }
      }
  }


void IO_init(void)
{
  PC_DDR|=0xdF;                         //PC  06,07��03,04,07�������ģʽ
  PC_CR1|=0xFF;
  PC_CR2|=0xDF;
  PC_ODR=0XFF;
  PD_DDR|=0xFF;                         //PC  06,07��03,04,07�������ģʽ
  PD_CR1|=0xFF;
  PD_CR2|=0xFF;
  PD_ODR=0XFF;
}
void main()
{ 
  unsigned const char * point= &picture_tab[0];
	CLK_init();
	IO_init();
	SPI_SCK_0;
	SPI_RST_0;
	delay_ms(1000);
	SPI_RST_1;
	delay_ms(1000);
	TFT_init();
	TFT_clear();
  while(1)
  {
    TFT_full(RED);
	delay_ms(1000);
	TFT_full(GREEN);
	delay_ms(1000);
	TFT_full(BLUE);
	delay_ms(1000);
	TFT_clear();
    SET_FONT_STYLE (RED,BLACK,SONG_STYLE12);//��������ʾ��ʽ    
    DIS_CHINESE(0,30,"GB2312�ֿ����");
		delay_ms(1000);TFT_clear();
        SET_FONT_STYLE (RED,GREEN,SONG_STYLE14);//��������ʾ��ʽ
	DIS_CHINESE(0,42,"GB2312�ֿ����");
		delay_ms(1000);TFT_clear();
        SET_FONT_STYLE (RED,BLUE,SONG_STYLE16);//��������ʾ��ʽ
	DIS_CHINESE(0,56,"GB2312�ֿ����");
		delay_ms(1000);TFT_clear();
        SET_FONT_STYLE (RED,WHITE,SONG_STYLE18);//��������ʾ��ʽ
	DIS_CHINESE(0,72,"GB2312�ֿ����");
		delay_ms(1000);TFT_clear();
        SET_FONT_STYLE (GREEN,BLACK,SONG_STYLE20);//��������ʾ��ʽ
	DIS_CHINESE(0,0,"GB2312�ֿ����");
	delay_ms(1000);TFT_clear();
        SET_FONT_STYLE (GREEN,RED,SONG_STYLE22);//��������ʾ��ʽ
	DIS_CHINESE(0,0,"GB2312�ֿ����");
	delay_ms(1000);TFT_clear();
    SET_FONT_STYLE (GREEN,BLUE,SONG_STYLE24);//��������ʾ��ʽ
	DIS_CHINESE(0,0,"GB2312�ֿ����");
	delay_ms(1000);TFT_clear();
    SET_FONT_STYLE (BLUE,BLACK,SONG_STYLE26);//��������ʾ��ʽ
	DIS_CHINESE(0,30,"GB2312�ֿ����");
	delay_ms(1000);TFT_clear();

		Picture_display(point);
//		Picture_ReverseDisplay(point);
	delay_ms(1000);
	}
}
